<?php
namespace App\Controllers\Admin;

class Users extends \Core\Controller
{
  protected function before()
  {

  }

  public function indexAction()
  {
    echo"welcome";
  }
}
