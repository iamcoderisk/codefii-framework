<?php
/**
 */

require 'public' . DIRECTORY_SEPARATOR . 'index.php';
