<?php

/**
 * Front controller
 *
 * PHP version 5.4
 */

/**
 * Composer
 */
require '../vendor/autoload.php';
require '../Core/Routes.php';


/**
 * Twig
 */
// Twig_Autoloader::register();


/**
 * Routing
 */
