<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Add post</title>
  </head>
  <body>
    <h2>Add post to database</h2>
    <form method="post" action="">
      <div class="">
        <input type="text" name="title" placeholder="text title" />
      </div>

      <div class="">
        <textarea name="content" placeholder="content"></textarea>
      </div>
      <div class="">
        <button type="submit" name="submit">Submit</button>
      </div>
    </form>

  </body>
</html>
