<form method="post"action="/try/framework/posts/addnew">
  <input type="text" name="name" />
  <input type="submit" name="submit" />
</form>
